# BruisedPortfolio

## Tristan Kania — IT Operations, Networking, CRM Systems & Investigative Technical Analysis

[![Portfolio Focus](https://img.shields.io/badge/Focus-IT%20Operations%20%7C%20Networking%20%7C%20CRM-blue)](#)
[![CCNA](https://img.shields.io/badge/Studying-Cisco%20CCNA-informational)](#)
[![Systems](https://img.shields.io/badge/Systems-Ubuntu%20Server%20%7C%20WireGuard%20%7C%20Jellyfin-success)](#)
[![Documentation](https://img.shields.io/badge/Style-Operator%20Logs%20%7C%20Root%20Cause%20Analysis-critical)](#)

Hands-on technical portfolio focused on Linux systems, networking, CRM operations, self-hosted infrastructure, open-source research workflows, and structured troubleshooting.

This portfolio documents real systems I have built, the problems I encountered, how I diagnosed them, and the solutions I implemented. The purpose is not just to show finished projects. The purpose is to show how I think when systems break: define the failure, isolate the layer, test one variable at a time, apply the fix, validate the result, and document the lesson.

My background combines operations leadership, Salesforce/Litify CRM workflows, legal intake analysis, incident documentation, homelab infrastructure, and open-source research methods. That combination gives me a practical foundation for IT operations, technical support, CRM systems support, junior systems administration, network support, and investigative analyst roles.

---

## Recruiter Snapshot

| Area | Proof |
|---|---|
| **Linux / Server Admin** | Ubuntu Server 24.04 homelab, systemd service checks, file permissions, CLI troubleshooting |
| **Networking** | WireGuard VPN, DHCP reservation, routing concepts, LAN service access, router configuration |
| **CRM / Ticketing** | Salesforce-based Litify workflows, high-volume intake records, case/ticket tracking, data integrity |
| **Troubleshooting** | Operator-log documentation with symptoms, assumptions, root cause, fix, validation, and lessons learned |
| **Investigation / Analysis** | Legal intake triage, incident documentation, OSINT-style source validation, timeline reconstruction |
| **Current Development** | Actively studying Cisco CCNA and building a documented homelab portfolio |

---

## Featured Projects

### 1. WireGuard VPN Server Deployment & Debugging

Built and configured a secure WireGuard VPN server using Ubuntu Server 24.04 to enable remote access into a private home network.

**What this project demonstrates:**

- Linux CLI usage
- VPN server configuration
- Peer setup and mobile onboarding
- QR code provisioning
- Routing troubleshooting
- Permission issue diagnosis
- Full-tunnel traffic validation

**Problems solved:**

- Permission denied errors inside `/etc/wireguard/`
- QR code generation issues
- Broken or malformed mobile peer configs
- VPN connection working but traffic not routing properly
- Confusion between “connected” and “actually routing through tunnel”

[View Project](./projects/wireguard-vpn-operator-log.md)

---

### 2. OpenClaw Gateway Setup & Troubleshooting

Worked through OpenClaw gateway setup, service behavior, configuration issues, and remote access problems while integrating local AI/control tooling into a home server environment.

**What this project demonstrates:**

- Linux service troubleshooting
- Systemd user service checks
- Config file debugging
- Gateway / Control UI troubleshooting
- Secure context and origin restriction analysis
- Local service access validation
- Iterative problem solving under unclear documentation

**Problems investigated:**

- Gateway service status and runtime behavior
- Control UI access restrictions
- Origin not allowed errors
- Device identity / HTTPS secure context issues
- Configuration syntax and allowed origin problems
- Service logs and restart behavior
- Signal CLI integration requirements
- Docker permission boundaries

[View Project](./projects/openclaw-gateway-operator-log.md)

---

### 3. Home Media Server — Jellyfin

Designed and deployed a private home media server using Jellyfin with local streaming access and future expansion in mind.

**What this project demonstrates:**

- Self-hosted media server setup
- Local network service access
- Storage planning
- Client-device integration
- Server vs NAS architecture decisions
- Practical home infrastructure planning

**Problems solved:**

- Determining whether a separate NAS was required
- Organizing storage for media access
- Understanding local vs remote access requirements
- Planning for Apple TV playback
- Designing for future scalability without unnecessary hardware spending

[View Project](./projects/jellyfin-media-server-case-study.md)

---

### 4. Home Network Optimization

Configured and troubleshot home network settings to support stable server access, VPN routing, and consistent internal addressing.

**What this project demonstrates:**

- Router configuration
- DHCP reservation planning
- Internal IP stability
- VPN/server role separation
- Local network troubleshooting
- Practical networking fundamentals

**Problems solved:**

- Server IP changing dynamically
- Confusion around DHCP reservation
- Router vs server responsibility overlap
- VPN routing concerns
- Local network reliability issues

[View Project](./projects/home-network-optimization-case-study.md)

---

### 5. OSINT & Investigative Workflow Study

Developed a structured open-source research workflow focused on ethical information gathering, source validation, timeline reconstruction, and analytical reporting.

**What this project demonstrates:**

- Open-source research discipline
- Source validation
- Timeline building
- Evidence organization
- Report writing
- Risk and credibility assessment
- Analytical thinking
- Documentation under uncertainty

**Professional connection:**

This workflow connects directly to IT operations, CRM analysis, fraud review, legal operations, security support, compliance, and technical support roles where accurate information gathering and documentation matter.

[View Project](./projects/osint-investigative-workflow.md)

---

## Skills Matrix

| Category | Tools / Concepts |
|---|---|
| **Operating Systems** | Ubuntu Server 24.04, Linux CLI, Windows |
| **Networking** | WireGuard VPN, DHCP reservation, routing concepts, LAN access, port forwarding concepts, router configuration |
| **Server / Homelab** | Jellyfin, CasaOS, OpenClaw Gateway, self-hosted services, local network services |
| **CRM / Data Systems** | Salesforce-based Litify CRM, case workflows, ticket-style records, data validation, pipeline tracking |
| **Documentation** | Root-cause analysis, operator logs, incident notes, case summaries, troubleshooting reports |
| **Investigation** | Source validation, timeline reconstruction, evidence organization, credibility review, structured intake |
| **Productivity / Tools** | Microsoft Word & Excel, GitHub, Google Workspace, DaVinci Resolve, AI-assisted workflows |

---

## Troubleshooting Method

Across these projects, I follow a repeatable troubleshooting structure:

1. Define expected behavior.
2. Capture the actual failure.
3. Identify the layer involved: system, network, application, configuration, access control, or permissions.
4. Test one variable at a time.
5. Apply the smallest reasonable fix.
6. Validate the result.
7. Document what changed and what was learned.

This matters because technical support and systems work are not only about knowing commands. They are about staying calm when behavior does not match expectations, isolating the failure, and communicating the resolution clearly.

---

## Professional Direction

I am currently targeting roles in:

- IT Operations
- Technical Support
- Help Desk / Tier II Support
- Junior Systems Administration
- Network Support
- CRM Systems Support
- Salesforce / Litify Operations
- Investigative / Technical Analyst Support

I am also actively studying for the **Cisco CCNA** to strengthen my networking foundation.

---

## Recommended Repo Navigation

```text
BruisedPortfolio/
├── README.md
├── projects/
│   ├── wireguard-vpn-operator-log.md
│   ├── openclaw-gateway-operator-log.md
│   ├── jellyfin-media-server-case-study.md
│   ├── home-network-optimization-case-study.md
│   └── osint-investigative-workflow.md
├── docs/
│   ├── skills-matrix.md
│   ├── resume-project-bullets.md
│   └── troubleshooting-method.md
└── templates/
    └── operator-log-template.md
```

---

## About This Portfolio

This portfolio is built from real troubleshooting work performed in my own environment. The focus is not just showing finished systems, but showing how I work through problems when systems break.

The goal is to show practical ability in:

- Diagnosing technical issues
- Working through incomplete information
- Documenting problems clearly
- Turning troubleshooting into repeatable knowledge
- Building confidence with real infrastructure
